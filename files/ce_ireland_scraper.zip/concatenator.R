###############################################################################
#
# Code developed to combine all the .csv files produced by scraping the
# townlands.ie website. Requires that you used "CP ScrapeBot.R" to produce the
# directory of Civil Parish information.
# Produces one .csv file containing all unique data.
#
# Author: Corey Emery
# Last Update: May 27, 2018
#
###############################################################################

### FOR THE USER ###

# Please set your working directory to the top-level directory produced by the
# scrapebot. This should be "Civil_Parish_Scraped".
setwd(".")

### DEPENDENCIES ###

library(tidyverse)

### CONCATENATOR ###

# Get a vecor of the paths to all .csv files of scraped civil parish info
paths <- vector()
for (i in 1:length(list.files("."))) {
  paths <- c(paths, list.files(paste("./", list.files(".")[i], sep = ""),
                               full.names = TRUE))
}

# Read in all of these files and concatenate them into one table
complete <- data.frame()
for (i in 1:length(paths)) {
  complete <- rbind(complete, read_csv(paths[i], col_types = cols(.default = "c")))
}

# Remove any duplicate information from this table
complete_unique <- complete[!duplicated(complete), ]

# A little more cleaning
inds <- which(grepl(" Parish", complete_unique$Townland, fixed = TRUE))
complete_unique[inds, ]$Townland <- sapply(strsplit(complete_unique[inds,]$Townland,
                                                    split = " - | \\("), "[[", 1)

inds <- which(grepl(" Parish", complete_unique$Civil_Parish, fixed = TRUE))
complete_unique[inds, ]$Civil_Parish <- substr(complete_unique[inds, ]$Civil_Parish, 1,
                  nchar(complete_unique[inds, ]$Civil_Parish) - nchar(" Civil Parish"))


# Write the table to a .csv file in the top-level directory
write_csv(complete_unique, "FULL_DATA.csv")
