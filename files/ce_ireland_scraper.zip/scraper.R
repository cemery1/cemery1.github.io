###############################################################################
#
# Code developed to scrape location data from the townlands.ie website.
# Produces a directory of directories, one per county.
# Each subdirectory contains one .csv file per civil parish containing
# all the townlands in that civil parish (as well as their associated county
# electoral division, and barony).
#
# Author: Corey Emery
# Last Update: May 25, 2018
#
###############################################################################

### FOR THE USER ###

# Please set your working directory to where you would like to store this data
setwd(".")

### DEPENDENCIES ###

library(rvest)
library(tidyverse)

### HELPER FUNCTIONS ###

# extract: extract an element from a table, handling error cases
# Input:
# - e: a list
# - i: an int
# Output: the ith element of e, or "" if i is out of range

extract <- function(e, i) {
  tryCatch(e[[i]], error = function(e) "")
}

# extract_civil_parish: extract the name of the current civil parish for each
#                       list element from a list of string vectors
# Input:
# - data: a list of string vectors
# Output: a vector of civil parish names, with the ith name corresponding to the
#         ith element of our original list, if no civil parish name present will
#         return the empty string for that element

extract_civil_parish <- function(data) {
  remove_last_2 <- function(e) {
    len <- length(e)
    i <- c((len - 1):len)
    return (e[-i])
  }
  # Vector element for Civil Parish
  elems <- sapply(data, function(e) which(grepl("Civil Parish", e, fixed = TRUE)))
  civil_parish_raw <- trimws(mapply(extract, data, elems))
  # Remove words "Civil Parish
  civil_parish <- sapply(lapply(strsplit(civil_parish_raw, split = " "),
                                remove_last_2), paste, collapse = " ")
  return (civil_parish)
}

# extract_barony: extract the name of the current barony for each list element
#                 from a list of string vectors
# Input:
# - data: a list of string vectors
# Output: a vector of barony names, with the ith name corresponding to the ith
#         element of our original list, if no barony name present will return
#         the empty string for that element

extract_barony <- function(data) {
  # Vector element for Barony
  elems <- sapply(data, function(e) which(grepl("Barony", e, fixed = TRUE)))
  barony_raw <- trimws(mapply(extract, data, elems))
  barony_raw_nonum <- trimws(lapply(strsplit(barony_raw,
                                             split = "[[:digit:]]"), extract, 1))
  # Remove words "Barony of"
  barony <- sapply(lapply(strsplit(barony_raw_nonum, split = " "),
                          function(e) e[-c(1,2)]), paste, collapse = " ")
  return (barony)
}

# extract_county: extract the name of the current county for each list element
#                 from a list of string vectors
# Input:
# - data: a list of string vectors
# Output: a vector of county names, with the ith name corresponding to the ith
#         element of our original list, if no county name present will return
#         the empty string for that element

extract_county <- function(data) {
  # Vector element for Barony
  elems <- sapply(data, function(e) which(grepl("Co. ", e, fixed = TRUE)))
  county_raw <- trimws(mapply(extract, data, elems))
  # Split this element to get rid of the area information at the end of the string
  county_raw_nonum <- trimws(lapply(strsplit(county_raw,
                                             split = "[[:digit:]]"), extract, 1))
  # Remove word Co.
  county <- sapply(lapply(strsplit(county_raw_nonum, split = " "),
                          function(e) e[-1]), paste, collapse = " ")
  return (county)
}

# extract_ded: extract the name of the current electoral division for each
#              townland on the given page
# Input:
# - page: the current page including all the townlands
# Output: a vector of electoral division names, with the ith name corresponding
#         to the ith townland extracted previously, if no name present will return
#         the empty string for that element
extract_ded <- function(page) {
  read_townland <- function(vec, i) {
    tryCatch(read_html(vec[i]), error = function(e) read_townland(vec, i))
  }
  
  links <- paste("https://www.townlands.ie",
                 page %>% html_nodes('h2~ ul li > a') %>% html_attr("href"),
                 sep = "")
  
  ded <- vector()
  for (i in 1:length(links)) {
    tpage <- read_townland(links, i)
    word <- tpage %>% html_nodes('#bc_ed span') %>% html_text()
    if (length(word) > 0) {
      wvec <- strsplit(word, split = " ")[[1]]
      addin <- wvec[-c(length(wvec) - 1:length(wvec))]
    } else {
      addin <- ""
    }
    ded <- c(ded, addin)
  }
  return (ded)
}

# scrape_html: get a data frame containing townland, civil parish, barony,
#              county, and electoral division data from a webpage
# Input:
# - page: an XML (HTML) document
# Output: A dataframe for all the townlands contained in this webpage.
#         Contains columns for townland, civil parish, barony, and county.
#         Missing data replaced by the empty string.

scrape_html <- function(page) {
  data <- page %>% html_nodes('h2~ ul li') %>% html_text()
  
  # Townland names
  townlands <- page %>% html_nodes('h2~ ul li > a') %>% html_text()
  
  # Only include ones that have their own pages on townlands.ie
  # All other townlands listed there reference one of these main townlands
  filter_ind <- which(sapply(data, grepl, pattern = "(see ", fixed = TRUE))
  if (length(filter_ind) == 0) {
    data_filtered <- data
  } else {
    data_filtered <- data[-(filter_ind)]
  }
  
  # Remove townland names from data
  data_rest <- strsplit(mapply(function(str, s) substr(str, nchar(s) + 1, nchar(str)),
                               data_filtered, townlands), split = ",")
  
  # Get the Civil Parish from each entry
  civil_parish <- extract_civil_parish(data_rest)
  
  # Get the Barony from each entry
  barony <- extract_barony(data_rest)
  
  # Get the County from each entry
  county <- extract_county(data_rest)
  
  # Get the Electoral Division (later addition)
  ded <- extract_ded(page)
  
  # Put it all together
  return (data.frame(Townland = townlands,
                     Civil_Parish = civil_parish,
                     Barony = barony,
                     Electoral_Division = ded,
                     County = county))
}

### SCRAPER ###

top_level_URL <- "https://www.townlands.ie/"

# Create Top Level Directory to store everything
# This will be put in your current working directory
dir.create("./Civil_Parish_Scraped")
setwd("./Civil_Parish_Scraped")

# Read webpage
homepage <- read_html(top_level_URL)

# Get the links and names for each the Counties
county_html <- html_nodes(homepage, 'h2+ ul a')
county_ext <- html_attr(county_html, "href")
county_names <- html_text(county_html)

# And now we loop
for (i in 1:length(county_ext)) {
  # Create Subdirectories for each County
  dir.create(paste("./", county_names[i], sep = ""))
  setwd(paste("./", county_names[i], sep = ""))
  
  # Add extension for current county and read that webpage
  county_URL <- paste(substr(top_level_URL, 1, nchar(top_level_URL) - 1),
                      county_ext[i], sep = "")
  countypage <- read_html(county_URL)
  
  # Find correct child for this page
  if (length(html_nodes(countypage, 'a+ h2')) > 1) {
    child <- 15
  } else {
    child <- 12
  }
  
  # Get links and names for each Civil Parish
  civil_parish_html <- html_nodes(countypage,
                                  paste('ul:nth-child(', child, ') a', sep = ""))
  civil_parish_ext <- html_attr(civil_parish_html, "href")
  civil_parish_names <- html_text(civil_parish_html)
  
  # And now we loop (again)
  for (j in 1:length(civil_parish_ext)) {
    # Add extension for current civil parish and read that webpage
    civil_parish_URL <- paste(substr(top_level_URL, 1, nchar(top_level_URL) - 1),
                              civil_parish_ext[j], sep = "")
    civilparishpage <- read_html(civil_parish_URL)
    
    # Scrape
    cp_df <- scrape_html(civilparishpage)
    
    # write the data to a csv in the current working directory
    file_name <- paste(strsplit(civil_parish_names[j], split = "/")[[1]],
                       collapse = "_")
    write_csv(cp_df, paste(file_name, ".csv", sep = ""))
  }
  
  # Go back to top level directory
  setwd("../")
}
